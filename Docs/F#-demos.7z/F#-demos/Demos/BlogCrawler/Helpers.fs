﻿#light

open System
open System.IO
open System.Net
open System.Collections
open System.Collections.Generic

let pythonLocation = "c:\\python26\\python.exe"

let rec unfoldl' acc f b =
  match f b with
    | Some (a, new_b) -> unfoldl' (a::acc) f new_b
    | None -> acc

let unfoldl f b = unfoldl' [] f b |> List.rev

let enumeratorToList (e:IEnumerator<_>) =
  let func (e:IEnumerator<_>) = if e.MoveNext()
                                then Some (e.Current, e)
                                else None in
    unfoldl func e

let enumeratorToListNonGeneric (e:IEnumerator) =
  let func (e:IEnumerator) = if e.MoveNext()
                                then Some (e.Current, e)
                                else None in
    unfoldl func e

let flatten (mylist: 'a list list) = 
    let acc = new List<'a>()
    mylist |> List.iter (fun l -> l |> List.iter (fun x -> acc.Add(x)))
    Seq.to_list acc

let toList (e:IEnumerable<_>) = 
    enumeratorToList (e.GetEnumerator())
    
let toListNon (e:IEnumerable) = 
    enumeratorToListNonGeneric (e.GetEnumerator())
    
let FlattenOption (optionList: 'b option list) =
    optionList |> List.filter (fun x -> x.IsSome) |> List.map (fun x -> x.Value)

let PrintAll (mylist: 'a list) =
    mylist |> List.iter (fun x -> print_any x
                                  Console.WriteLine())

let getGoodFileName (str: string) = 
    let chars = "abcdefghijklmnopqrstuvwxyz"
    let result = str.ToCharArray() |> Array.filter (fun x -> chars.Contains(x.ToString()))
    System.String(result)


// Network functions
let cacheObj = new System.Object()
let cache = lock cacheObj (fun () -> let tempCache = new List<string>()
                                     use stream = new StreamReader("cache.txt")
                                     while not (stream.EndOfStream) do 
                                        tempCache.Add(stream.ReadLine())
                                     done
                                     tempCache)
   
let getUrlCache () = cache;

let writeUrlCache () = lock cache (fun () -> use stream = new StreamWriter("cache.txt")
                                             cache |> Seq.to_list |> List.iter (fun x -> stream.WriteLine(x)))

let addToUrlCache (url: string) = lock cache (fun () -> cache.Add(url))
                                  writeUrlCache ()


let getUrl (url: string) =
    try
        if (getUrlCache().Contains(url) || url.Contains(".zip") || url.Contains(".bin") || url.Contains(".pdf") || url.Contains(".mov") || url.Contains(".avi") || url.Contains(".pdf") || url.Contains(".png") || url.Contains(".gif") || url.Contains(".jpeg")) then 
            ""
        else
            Console.WriteLine("[http] getting: " + url)
            let request = HttpWebRequest.Create(url)
            request.Timeout <- 5000
            let response = request.GetResponse()
            let responseReader = new StreamReader(response.GetResponseStream())
            let result = responseReader.ReadToEnd()
            response.Close()
            responseReader.Close()
            addToUrlCache(url)
            result
    with ex -> addToUrlCache(url)
               ""  

let consoleLockObj = new System.Object()

let greenConsole (message: string) = 
    // we need to lock, because there's a race condition otherwise
    lock consoleLockObj (fun () -> let old = Console.ForegroundColor
                                   Console.ForegroundColor <- ConsoleColor.Green
                                   Console.WriteLine(message)
                                   Console.ForegroundColor <- old)

let redConsole (message: string) = 
    // we need to lock, because there's a race condition otherwise
    lock consoleLockObj (fun () -> let old = Console.ForegroundColor
                                   Console.ForegroundColor <- ConsoleColor.Red
                                   Console.WriteLine(message)
                                   Console.ForegroundColor <- old)    