﻿#light

open System
open System.IO
open System.Net
open System.Collections.Generic

let lockObj = new System.Object()
let indexObj = new System.Object()

type IndexEntry = {
    rssUrl : string;
    indexKey : string;
    lastAccessed : DateTime;
}
 
// url,rssurl
let slurpUrlToRss (filename: string) = 
    lock lockObj (fun () -> use reader = new StreamReader(filename)
                            let dict = new Dictionary<string, string>()
                            while not (reader.EndOfStream) do
                                let line = reader.ReadLine()
                                let split = line.Split([|','|], StringSplitOptions.RemoveEmptyEntries)
                                dict.Add(split.[0], split.[1])
                            done 
                            dict)

let putUrlToRss(filename: string) (dict: Dictionary<string, string>) = 
    lock lockObj (fun () -> use writer = new StreamWriter(filename)
                            Seq.to_list dict |> List.iter (fun (x: KeyValuePair<string, string>) -> writer.WriteLine(x.Key + "," + x.Value)))
                            


let getNextIndexDir (directory: string) (index: IndexEntry list) = 
    let max = index |> List.map (fun x -> System.Int32.Parse(x.indexKey)) |> List.max 
    let nextDir = max + 1
    nextDir

// rssurl,dir,datetime        
let getIndex (filename: string) = 
    lock indexObj (fun () -> use reader = new StreamReader(filename)
                             let list = new List<IndexEntry>()
                             while not (reader.EndOfStream) do
                                let line = reader.ReadLine()
                                let split = line.Split([|','|], StringSplitOptions.RemoveEmptyEntries)
                                list.Add({ rssUrl = split.[0]; indexKey = split.[1]; lastAccessed = DateTime.Parse(split.[2]) })
                             done
                             Seq.to_list list)

let updateIndex (filename: string)  (url: string) = 
    let index = getIndex (filename)
    let found = index |> List.first (fun x -> if x.rssUrl = url then Some(x) else None)
    if (found.IsSome) then 
        let old = index |> List.filter (fun x -> not (x.rssUrl = url))
        let newIndex = List.Cons ({ rssUrl = found.Value.rssUrl;
                                    indexKey = found.Value.indexKey;
                                    lastAccessed = DateTime.Now;}, old)
        lock indexObj (fun () -> use writer = new StreamWriter(filename)
                                 newIndex |> List.iter (fun x -> writer.WriteLine(x.rssUrl + "," + x.indexKey + "," + x.lastAccessed.ToString())))


let addToIndex (directory: string) (filename: string) (url: string) = 
    let index = getIndex (filename)
    let found = index |> List.filter (fun x -> x.rssUrl = url)
    if (found.Length = 0) then 
        let newIndex = List.Cons ({ rssUrl = url.Replace(",","");
                                    indexKey = (getNextIndexDir directory index).ToString();
                                    lastAccessed = DateTime.MinValue;}, index)
        lock indexObj (fun () -> use writer = new StreamWriter(filename)
                                 newIndex |> List.iter (fun x -> writer.WriteLine(x.rssUrl + "," + x.indexKey + "," + x.lastAccessed.ToString())))
    else
        Console.WriteLine("[error] tried to add duplicate to index")



//let saveIndex (filename: string) (index: List<string>) = 
//    lock indexObj (fun () -> use writer = new StreamWriter(filename)
//                             Seq.to_list index |> List.iter (fun (x: string) -> writer.WriteLine(x)))


