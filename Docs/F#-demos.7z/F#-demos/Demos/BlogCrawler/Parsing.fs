﻿#light

open System
open System.IO
open System.Net
open System.Xml
open System.Xml.Linq
open System.Collections.Generic
open System.Diagnostics
open HtmlAgilityPack
open Helpers
open Rss

type RssFeedItem = {
    rssUrl : string;
    title : string;
    pubDate : string;
    author : string;
    content : string;
    links : string list;
}

let getRoot (html: string) = 
    try
        let htmlDocument = new HtmlDocument()
        use stringWriter = new StringWriter()
        htmlDocument.LoadHtml(html)
        htmlDocument.OptionOutputAsXml <- true
        htmlDocument.Save(stringWriter)
        let xdoc = XDocument.Parse(stringWriter.GetStringBuilder().ToString())
        xdoc.Root
    with ex -> new XElement(XName.Get("Nothing","Nothing"))

let flattenXElement (elem: XElement) =
    let rec flatten acc (elem: XElement) = 
        let mylist = toList (elem.Elements())
        if List.length (mylist) <= 0 then elem :: acc
        else mylist |> List.map (fun x -> flatten acc x) |> List.flatten
    flatten [] elem

let fullyQualify (elem: XElement) =
    let rec flatten (acc: string) (elem: XElement) =
        match (elem) with 
        | null -> acc.Substring(0, acc.Length-1)
        | _ -> 
            let acc = elem.Name.LocalName + "." + acc
            flatten acc elem.Parent
    flatten "" elem

let findHelper (elem: XElement) (s: string) myfun = 
    let flat = flattenXElement elem
    let qualified = flat |> List.map (fun x -> fullyQualify x)
    qualified |> List.filter (myfun)

let findAny (elem: XElement) (s: string) = 
    findHelper elem s (fun x -> x.LastIndexOf(s) = (x.Length - s.Length))
    
let find (elem: XElement) (s: string) = 
    findHelper elem s (fun (x: string) -> x.Equals(s))

let findElems (elem: XElement) (s: string) =
    flattenXElement elem |> List.filter (fun x -> x.Name.LocalName = s)
    
let findText (elem: XElement) (s: string) = 
    let flat = flattenXElement elem
    let xnodes = flat |> List.map ( fun (x: XElement) -> toList (x.Nodes()) )
    let xnames = (List.flatten xnodes) |> List.filter ( fun (x: XNode) -> x.GetType().Name = "XText") 
    xnames |> List.filter (fun (x: XNode) -> (x :?> XText).Value.Contains(s)) |> List.map ( fun (x: XNode) -> x.Parent )

let findAttribute (elem: XElement) (s: string) = 
    elem.Attributes() |> Seq.to_list |> List.first (fun (x: XAttribute) -> match x.Name.LocalName.ToLower().Contains(s.ToLower()) with 
                                                                            | true -> Some(x) 
                                                                            | false -> None)


// TODO://
//let extractLinksFromHtml (currentUrl: string) (elem: XElement) = 
//    let links = findElems elem "a"
//    links |> List.map (fun x -> findAttribute x "href")
//          |> FlattenOption
//          |> List.map (fun x -> x.Value.ToLower())
//          |> List.map (fun x -> if not (x.Contains("http://")) then 
//                                    currentUrl + x
//                                else
//                                    x)
                                    
let extractLinksFromHtml (url: string) (html: string) = 
    let wrapper = Html.Markdown.Html2MarkdownWrapper(pythonLocation)
    let markdown = wrapper.ConvertHtml2Markdown(html)
    Seq.to_list (wrapper.ExtractHtmlLinksFromMarkdown(markdown, url)) |> List.filter (fun x -> not (x.Contains("jpg")) && not (x.Contains("bmp")) && not (x.Contains("png")) && not (x.Contains("zip")))


// RSS functions
//let findRssFeed (elem: XElement) = 
//    let links = findElems elem "link"
//    links   |> List.filter (fun (x: XElement) -> let res = findAttribute x "type"
//                                                 if res.IsSome then
//                                                    res.Value.Value.Contains("rss")
//                                                 else
//                                                    false)
//            |> List.map (fun x -> findAttribute x "href")
//            |> FlattenOption
//            |> List.map (fun x -> x.Value)

let findRssFeed (url: string) (html: string)  = 
    let wrapper = Html.Markdown.Html2MarkdownWrapper(pythonLocation)
    Seq.to_list (wrapper.GetRssLinks(html, url))
    
    



//let tryAndGetRssLink (url: string) = 
//    let result = getUrl url
//    if (result.Contains("<rss version=\"2.0\"")) then
//        greenConsole ("[rss] found: " + url)
//        Some (url)
//    else if (System.String.IsNullOrEmpty(result)) then 
//        None
//    else
//        let feedLink = findRssFeed (getRoot result)
//        if (feedLink.Length > 0) then 
//            if not (System.String.IsNullOrEmpty(feedLink.Head)) then
//                greenConsole ("[rss] found: " + feedLink.Head)
//                Some (feedLink.Head)
//            else
//                None
//        else 
//            None
            
let tryAndGetRssLink (url: string) = 
    let result = getUrl url
    if (result.Contains("<rss version=\"2.0\"")) then
        greenConsole ("[rss] found: " + url)
        Some (url)
    else if (System.String.IsNullOrEmpty(result)) then 
        None
    else
        let feedLink = findRssFeed url result
        if (feedLink.Length > 0) then 
            if not (System.String.IsNullOrEmpty(feedLink.Head)) then
                greenConsole ("[rss] found: " + feedLink.Head)
                Some (feedLink.Head)
            else
                None
        else 
            None
                     


let parseRssFeed (url: string) =     
    try
        let feed = RssFeed.Read(url)
        toListNon feed.Channels.[0].Items |> List.map (fun x -> let item = (x :?> RssItem)
                                                                { rssUrl = item.Link.ToString();
                                                                  title = item.Title;
                                                                  pubDate = item.PubDate.ToString();
                                                                  author = item.Author;
                                                                  content = item.Description
                                                                  links = extractLinksFromHtml url item.Description
                                                                })
    with ex -> []


let hasGoodContent (item: RssFeedItem) = 
    item.content.Length > 50

let writeOutFeedToIndex (directory: string) (items : RssFeedItem list) =
    if not (Directory.Exists(directory)) then 
        Directory.CreateDirectory(directory) |> ignore
    items |> List.iter (fun x ->  let title = directory + "\\" + getGoodFileName x.title + ".txt"
                                  use writer = new StreamWriter(title)
                                  writer.WriteLine(x.title)
                                  writer.WriteLine(x.rssUrl)
                                  writer.WriteLine(x.author)
                                  writer.WriteLine(x.pubDate)
                                  x.links |> List.iter (fun y -> writer.Write (y + ";"))
                                  writer.WriteLine()
                                  writer.WriteLine("[[]]")
                                  writer.WriteLine(x.content))

    
