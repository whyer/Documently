﻿#light

// Used for the F# Interactive
//#r @"C:\Program Files\Reference Assemblies\microsoft\framework\v3.5\System.Xml.Linq.dll"
//#r @"C:\Program Files\Reference Assemblies\microsoft\framework\v3.5\System.Data.Linq.dll"
//#r @"C:\Program Files\Reference Assemblies\microsoft\framework\v3.5\System.Core.dll"

open System
open System.IO
open System.Net
open System.Collections.Generic
open System.Diagnostics
open Helpers
open Parsing
open Indexing

type System.Net.WebRequest with
    member x.GetResponseAsync() =
        Async.BuildPrimitive(x.BeginGetResponse, x.EndGetResponse)

let timespan = new TimeSpan(5, 0, 0, 0)


let fetchFeedReturnMoreUrls (item: IndexEntry) = 
    async { let feed = parseRssFeed item.rssUrl
            let goodFeeds = feed |> List.filter (fun f -> hasGoodContent f)
            writeOutFeedToIndex item.indexKey goodFeeds
            let linkResults = goodFeeds |> List.map (fun z -> z.links |> List.map (fun link -> tryAndGetRssLink link))
            return (flatten linkResults) |> List.filter (fun z -> z.IsSome) |> List.map (fun z -> z.Value) }


while (true) do 
    try
    // grab a list of links we haven't parsed in a few days
        let parallelGet = Async.Run (Async.Parallel
                            [for site in getIndex "index.txt" |> List.filter (fun x -> x.lastAccessed < DateTime.Now.Subtract(timespan)) -> fetchFeedReturnMoreUrls site])

        getIndex "index.txt" |> List.iter (fun x -> updateIndex "index.txt" x.rssUrl)

        parallelGet |> Array.to_list |> flatten |> List.iter (fun z -> addToIndex "." "index.txt" z)
    
    with ex -> redConsole("[error] crashed out in the while loop")

done



 
//while (true) do 
//    // grab a list of links we haven't parsed in a few days
//    getIndex "index.txt" |> List.iter (fun x -> let feed = parseRssFeed x.rssUrl
//                                                let goodFeeds = feed |> List.filter (fun f -> hasGoodContent f)
//                                                writeOutFeedToIndex x.indexKey goodFeeds
//                                                let linkResults = goodFeeds |> List.map (fun z -> z.links |> List.map (fun link -> tryAndGetRssLink link))
//                                                let rssFeeds = (flatten linkResults) |> List.filter (fun z -> z.IsSome) |> List.map (fun z -> z.Value)
//                                                rssFeeds |> List.iter (fun z -> addToIndex "." "index.txt" z))
//                                                                  
//    // update the index to show that we've parsed the links                                
//    getIndex "index.txt" |> List.iter (fun x -> updateIndex "index.txt" x.rssUrl)
//done
                            
                            


Console.ReadLine() |> ignore