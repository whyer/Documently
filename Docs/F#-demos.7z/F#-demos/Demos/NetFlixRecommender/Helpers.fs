﻿#light

open System
open System.IO
open System.Text;
open System.Collections.Generic
open System.Data
open System.Data.SqlClient
open Types

let sqlConnectionString = @"Data Source=.\SQL01;Initial Catalog=NF;Integrated Security=True;";


let groupBy (f: 'T -> 'U) (l: 'T list) = 
    l |> List.map (fun x -> let (fail, success) = l |> List.partition (fun y -> f(y) = f(x))
                            (f(x), success))

let findOrZero (movieId: int) (a: Rating list) = 
    let res = a |> List.tryFind(fun x -> x.MovieId = movieId)
    if (res.IsSome) then 
        double res.Value.Rating
    else
        double 0

let addToDict (key: int) (item: double) (dict: Dictionary<int, double>) = 
    if (dict.ContainsKey(key)) then 
        dict.[key] <- dict.[key] + item
    else
        dict.Add(key, item)
        

let take (num: int) (mylist: 'a list) =
    if (mylist.Length < num) then
        mylist
    else
        let accumulator = new List<'a>()
        for i = 0 to num-1 do 
            accumulator.Add(mylist.[i])
        Seq.to_list accumulator 

let matchAndFlatten (a: Rating list) (b: Rating list) = 
    let matched = a |> List.map (fun x -> b |> findOrZero (x.MovieId))
    (List.to_array (a |> List.map (fun x -> double x.Rating)), List.to_array matched)
    

let flattenWithDelimiter (mylist: 'a list) (delimiter: string) = 
    let builder = new StringBuilder()
    mylist |> List.iter (fun x -> builder.Append(x.ToString()) |> ignore; builder.Append(delimiter) |> ignore)
    // now we have to cut the last delimiter
    let result = builder.ToString()
    result.Substring(0, result.Length-1)


let executeDbCall (sqlString: string) projection =
    let connection = new SqlConnection(sqlConnectionString)
    do connection.Open()
    let command = new SqlCommand(sqlString, connection)
    use reader = command.ExecuteReader(CommandBehavior.CloseConnection)
    projection reader


let getRatingsFromSimilarCustomers (movieIds: Rating list) =
    let movieIdSqlString = flattenWithDelimiter (movieIds |> List.map (fun x -> x.MovieId)) ","
    let sqlString = String.Format("select movieid, customerid, rating from ratings where ratings.customerid in ( SELECT TOP 50 ratings.customerid from ratings, customercounts where ratings.movieid in ({0}) and ratings.customerid = customercounts.customerid and customercounts.totalratings > 5 group by ratings.customerid, customercounts.totalratings order by count(*) DESC, customercounts.totalratings)", movieIdSqlString)
    executeDbCall sqlString 
        (fun (reader: SqlDataReader) ->
            let resultList = new List<_>()
            while (reader.Read()) do
                resultList.Add({    MovieId = reader.GetInt32(0)
                                    CustomerId = reader.GetInt64(1)
                                    Rating = reader.GetInt16(2)})
            resultList)
 

let getTotalRatingCount = 
    let sqlString = @"select sum(totalratings) from ratingcounts";
    executeDbCall sqlString
        (fun (reader: SqlDataReader) ->
            if (reader.Read()) then 
                reader.GetInt32(0)
            else
                0
        )


let ratingToMovieTitle (movieId: int) = 
    let sqlString = String.Format("select title from movie_titles where movieid = {0}", movieId)
    executeDbCall sqlString
        (fun (reader: SqlDataReader) ->
            if (reader.Read()) then
                reader.GetString(0)
            else
                ""
        )


let getMovieTitles =
    let sqlString = @"select movieid, title from movie_titles"
    executeDbCall sqlString
        (fun (reader: SqlDataReader) ->
            let cache = Dictionary<int, string>()
            while (reader.Read()) do
                cache.Add(reader.GetInt32(0), reader.GetString(1))
            cache
        )
        
let movieTitle (x: int) = 
    let cache = getMovieTitles
    if cache.ContainsKey(x) then cache.[x]
    else 
        ""