﻿#light

open System
open System.IO
open System.Collections.Generic
open System.Data
open System.Data.SqlClient
open Types
open Helpers


// Vector math to perform cosine similarity
let calculateLength (vector: double array) = 
    let mutable innerSum = 0.0
    for index = 0 to vector.Length - 1 do
        innerSum <- innerSum + (vector.[index] * vector.[index])
    done
    double (Math.Sqrt(innerSum))

let innerProduct (alpha: double array) (beta: double array) = 
    let mutable acc = 0.0
    for index = 0 to alpha.Length - 1 do
        acc <- acc + (alpha.[index] * beta.[index])
    done
    acc
    
let calculateSimilarity (alpha: double array) (beta: double array) = 
    (innerProduct alpha beta) / ((calculateLength alpha) * (calculateLength beta))
    

//let myFavouriteMovies = [{ MovieId = 331; CustomerId = int64 0; Rating = 5s}; { MovieId = 788; CustomerId = int64 0; Rating = 5s}];

let recommend (myFavouriteMovies: Rating list) =
    // Grab a list of customers who have rated the same movies as me
    let neighbours = Seq.to_list (getRatingsFromSimilarCustomers myFavouriteMovies)
                     |> groupBy (fun (x:Rating) -> x.CustomerId)

    // Now sort my neighbours by similarity
    let sortedNeighbours = neighbours |> List.map (fun (customerId, ratings) -> let (myratings, theirRatings) = matchAndFlatten myFavouriteMovies ratings
                                                                                let similarity = calculateSimilarity myratings theirRatings
                                                                                (customerId, similarity, ratings))
                                      |> List.sortBy (fun (customerId, similarity, ratings) -> similarity / -1.0)
                                      |> take 100
                                      

                                            
    let listOfNeighboursRecommendations = 
        let movieToRec = Dictionary<int, double>()
        sortedNeighbours |> List.iter (fun (_, similarity, ratings) -> 
                                       ratings |> List.iter (fun (x:Rating) -> 
                                                             addToDict x.MovieId (similarity * double x.Rating) movieToRec))
        Seq.to_list movieToRec |> List.sortBy (fun (keyValuePair) -> keyValuePair.Value / -1.0)



    listOfNeighboursRecommendations |> take 25
                                   

