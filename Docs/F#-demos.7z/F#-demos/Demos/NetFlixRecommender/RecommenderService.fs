﻿#light

open System
open System.IO
open System.Collections.Generic
open System.Diagnostics
open System.ServiceModel
open System.Runtime.Serialization
open Program
open Helpers
open Types


[<DataContract(Namespace="http://callvirt.net/samples")>]
type RecommendationResultItem () = 
    let mutable movieId: int = 0
    let mutable title: string = String.Empty
    let mutable strength: double = 0.0

    [<DataMember(Name = "MovieId", IsRequired = false, Order = 0)>]
    member public l.MovieId
        with get() = movieId
        and set(value) = movieId <- value
        
    [<DataMember(Name = "Title", IsRequired = false, Order = 1)>]
    member public l.Title
        with get() = title
        and set(value) = title <- value    


    [<DataMember(Name = "Strength", IsRequired = false, Order = 2)>]
    member public l.Strength
        with get() = strength
        and set(value) = strength <- value

[<DataContract(Namespace="http://callvirt.net/samples", Name="RecommendationResultContract")>]
type Recommendation () = 
    let mutable results: List<RecommendationResultItem> = new List<RecommendationResultItem>()
        
    [<DataMember(Name = "Results", IsRequired = false, Order = 1)>]
    member public l.Results
        with get() = results
        and set(value) = results <- value
        
        

[<ServiceContract(Name = "RecommenderService", Namespace = "http://callvirt.net/samples", ConfigurationName = "IRecommenderService")>]
type IRecommenderService =
    [< OperationContract >]
    abstract Recommend: moviesYouLike: List<Rating> -> Recommendation


[<ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)>] 
type RecommenderService() =
    interface IRecommenderService with
        member s.Recommend(moviesYouLike: List<Rating>) : Recommendation =
            let results = recommend (Seq.to_list moviesYouLike)
            let recommendation = new Recommendation()
            let resultsList = new List<RecommendationResultItem>()
            results |> List.iter (fun x -> resultsList.Add(new RecommendationResultItem (MovieId = x.Key, Title = ratingToMovieTitle x.Key, Strength = x.Value)))
            recommendation.Results <- resultsList
            recommendation
                                                          
            


let main() =
    Console.WriteLine("Recommendation Service = " + typeof<RecommenderService>.ToString())
    
    Console.WriteLine("starting service...")
    let hisType = typeof<RecommenderService>
    let host = new ServiceHost(hisType, ([| |] : Uri[] ) )
    host.Open()
    Console.WriteLine("Press <ENTER> to terminate the host application")
    Console.ReadLine() |> ignore
    host.Close()

main()