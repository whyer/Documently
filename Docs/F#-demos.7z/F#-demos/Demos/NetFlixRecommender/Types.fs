﻿#light


type Rating = {
    MovieId : int; 
    CustomerId : int64;
    Rating : int16; 
} 

