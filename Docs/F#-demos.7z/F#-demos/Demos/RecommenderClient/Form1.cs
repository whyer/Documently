﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RecommenderClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nFDataSet.movie_titles' table. You can move, or remove it, as needed.
            this.movie_titlesTableAdapter.Fill(this.nFDataSet.movie_titles);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int index = listBox1.FindString(textBox1.Text);
            listBox1.SelectedIndex = index;
        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            // grab the movieid
            DataRowView movieTitle = (DataRowView)listBox1.Items[listBox1.SelectedIndex];

            movieIds.Text += movieTitle.Row["movieid"] +","; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] movies = movieIds.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<TypesRating> ratings = new List<TypesRating>();
            foreach (var q in movies)
            {
                TypesRating temp = new TypesRating();
                temp.MovieId = int.Parse(q);
                temp.Rating = 5;
                temp.CustomerId = 0;
                ratings.Add(temp);
            }

            RecommenderServiceClient client = new RecommenderServiceClient();
            callvirt.net.samples.RecommendationResultContract result = client.Recommend(ratings.ToArray());

            result.Results.Reverse();
            foreach (var q in result.Results)
            {
                listBox2.Items.Add(q.Strength + ": " + q.Title);
            }

            textBox1.Text = "";
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DataRowView movieTitle = (DataRowView)listBox1.Items[listBox1.SelectedIndex];

                movieIds.Text += movieTitle.Row["movieid"] + ",";

                textBox1.Text = "";
            }

        }
    }
}
