//Copyright (C) 2007 Matthew Johnson

//This program is free software; you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation; either version 2 of the License, or
//(at your option) any later version.

//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.

//You should have received a copy of the GNU General Public License along
//with this program; if not, write to the Free Software Foundation, Inc.,
//51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SVM;

namespace SVMDemo
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            // lets tinker
            List<Node[]> nodes = new List<Node[]>()
            {
                // dog, cat, cow, technology
                new Node[3] { new Node(1, 1), new Node(2, 1), new Node(3, 1) },
                new Node[3] { new Node(1, 2), new Node(2, 1), new Node(3, 2) },
                new Node[2] { new Node(2, 2), new Node(3, 2) },
                new Node[3] { new Node(1, 1), new Node(2, 1), new Node(3, 1) },
                new Node[1] { new Node(4, 3) }
            };

            double[] Y = new double[5] { -1, -1, -1, -1, 1 };

            Node[][] arr = nodes.ToArray();

            Problem problem = new Problem(nodes.Count, Y, arr, 4);
            RangeTransform range = Scaling.DetermineRange(problem);
            problem = Scaling.Scale(problem, range);

            Parameter param = new Parameter();
            param.C = 2;
            param.Gamma = .5;
            Model model = Training.Train(problem, param);

            // try the assignment of animals
            Node[] test = new Node[4] { new Node(1, 2), new Node(2, 0), new Node(3, 1), new Node(4, 1) };
            test = range.Transform(test);
            int assignment = (int)Prediction.Predict(model, test);

            // try the assigmnet of technology
            Node[] test2 = new Node[1] { new Node(4, range.Transform(4, 4)) };
            //test2 = range.Transform(test2);
            int assignment2 = (int)Prediction.Predict(model, test2);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new SVMDemoForm());
        }
    }
}