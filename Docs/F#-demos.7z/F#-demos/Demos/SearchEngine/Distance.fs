﻿#light 

open System
open System.IO
open System.Collections.Generic
open System.Text
open Types

// shamelessly borrowed from http://www.navision-blog.de/2008/11/01/damerau-levenshtein-distance-in-fsharp-part-ii/
let calcDL (a:'a array) (b: 'a array) =
  let n = a.Length + 1
  let m = b.Length + 1
  let lastLine = ref (Array.init m (fun i -> i))
  let lastLastLine = ref (Array.create m 0)
  let actLine = ref (Array.create m 0)

  for i in [1..a.Length] do
    (!actLine).[0] <- i
    for j in [1..b.Length] do
      let cost =
        if a.[i-1] = b.[j-1] then 0 else 1
      let deletion = (!lastLine).[j] + 1
      let insertion = (!actLine).[j-1] + 1
      let substitution = (!lastLine).[j-1] + cost
      (!actLine).[j] <-
        deletion
        |> min insertion
        |> min substitution

      if i > 1 && j > 1 then
        if a.[i-1] = b.[j-2] && a.[i-2] = b.[j-1] then
          let transposition = (!lastLastLine).[j-2] + cost
          (!actLine).[j] <- min (!actLine).[j] transposition

    // swap lines
    let temp = !lastLastLine
    lastLastLine := !lastLine
    lastLine := !actLine
    actLine := temp

  (!lastLine).[b.Length]


// calculate the edit-distance between a and b
let calculateStringDistance(a: string) (b: string) =
  if a.Length > b.Length then
    calcDL (a.ToLower().ToCharArray()) (b.ToLower().ToCharArray())
  else
    calcDL (b.ToLower().ToCharArray()) (a.ToLower().ToCharArray())
    



// Calculate the edit distance of all words in the (word * termCount) dictionary
// Filter by distance, and sort by termCount
let findBestSearchTermMatch (searchTerm: string) (termList: KeyValuePair<string, int> list) = 
    termList |> List.map (fun keyvalue -> keyvalue.Key, keyvalue.Value, calculateStringDistance keyvalue.Key searchTerm)
        |> List.filter (fun (index, weight, distance) -> distance < 3)
        |> List.filter (fun (index, weight, distance) -> distance > 0)
        |> List.sortBy (fun (index, weight, distance) -> float weight / -1.0)
        |> List.hd


// Find a list of words that best match the search term
let getDidYouMean (searchTerms: string list) =
    let didYouMeanResult = new StringBuilder()
    
    let flattenedGlobalWordVector = Seq.to_list globalTermFrequency
    let didYouMean = searchTerms |> List.map (fun x -> findBestSearchTermMatch x flattenedGlobalWordVector)
    if didYouMean.Length > 0 then
        didYouMean |> List.iter (fun (indexTerm,_,_) -> didYouMeanResult.Append(indexTerm) |> ignore)
    didYouMeanResult.ToString()

