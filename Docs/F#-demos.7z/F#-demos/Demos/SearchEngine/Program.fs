﻿#light

open System
open System.IO
open System.Collections.Generic
open System.Diagnostics
open System.Text
open System.Threading
open System.ServiceModel
open System.Runtime.Serialization
open Helpers
open SVMClassifier
open Types
open Distance
open SVM


// TF-IDF: (termCount / totalTermCountsInDocument) * (totalDocuments / numDocumentsWhereTermAppears)
let updateDocumentTfIdf (allDocumentCount: int) (doc: Document) =
    let wordVectorList = Seq.to_list doc.wordvector
    let documentWordCount = wordVectorList |> List.sumBy (fun x -> let (count, tfidf) = x.Value
                                                                   count)
    wordVectorList |> List.iter (fun x -> let (wf, tfidf) = x.Value
                                          let tf = double wf / double documentWordCount
                                          let idf = Math.Log(float allDocumentCount / float globalTermFrequency.[x.Key])
                                          let newTfIdf = (wf, (tf*idf))
                                          doc.wordvector.[x.Key] <- newTfIdf)


// This function filters out all the HTML garbage, and returns a dictionary of 
// string, (int * double)
let parseDocumentContentToWords (words: string array) =
    let dict = new Dictionary<string, (int * double)>()
    words |> Array.filter (fun x -> not (stopWords.ContainsKey(x)) && isAlpha(x))
          |> Array.iter (fun x -> updateLocalDictionary dict x)
    dict  

// Parse a blog post in to a document type
let parseDocument (location: string) (str: string) = 
    let stringReader = new StringReader(str)
    let title = stringReader.ReadLine()
    let rsslink = stringReader.ReadLine()
    let author = stringReader.ReadLine()
    let date = parseDateTime(stringReader.ReadLine())
    let links = Array.to_list (stringReader.ReadLine().Split([|','|]))
    let content = (stringReader.ReadToEnd().ToLower() + " " + title.ToLower()).Split([|' ';',';'-';'.'|])
    { location = location; title = title; rssurl = rsslink; author = author; date = date; links = links; wordvector = parseDocumentContentToWords content; flatvector = [0.0]; classified = false;}



let slurpUpIndexFromDisk (location: string) = 
    let files = Array.to_list (Directory.GetFiles(location, "*.txt", SearchOption.AllDirectories))
    files |> List.map (fun file -> use fileStream = new StreamReader(file)
                                   parseDocument file (fileStream.ReadToEnd()))
          |> List.filter (fun doc -> doc.wordvector.Count > 50)


// Slurp up the corpus, update the global dictionary of
let initializeSearchEngine () = 
    // Main() -- slurp up all the blog posts from disk and return them as Documents
    Types.documents <- slurpUpIndexFromDisk "C:\\Data\\Blogs"
    Types.documents |> List.iter (fun x -> x.wordvector |> Seq.to_list |> List.iter (fun y -> updateGlobalDictionary globalTermFrequency y.Key))

    // update the Document.wordVector to contain the tfidf of each word
    Types.documents |> List.iter (fun x -> updateDocumentTfIdf documents.Length x)
    
    
    
// Perform a search across all documents
let search (searchTerms: string list) = 
    Types.documents |> List.map (fun x -> (x, (dictFreq x.wordvector searchTerms))) 
                    |> List.filter (fun (doc, freq) -> freq > 0.0)
                    |> List.sortBy (fun (doc, freq) -> (freq / -1.0))
                    |> take 20