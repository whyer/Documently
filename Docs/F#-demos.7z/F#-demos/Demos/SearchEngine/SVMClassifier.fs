﻿open System
open System.IO
open System.Collections.Generic
open System.Diagnostics
open System.Text
open System.Threading
open System.ServiceModel
open System.Runtime.Serialization
open Helpers
open Types
open SVM



// This function translates a Document in to the SVM vector model
// ready for training or consumption
let documentToSVMModel (doc: Document) (range: RangeTransform) = 
    let flattenedGlobalWordVector = dictionaryToArray globalTermFrequency
    let list = new List<Node>()
    for i = 0 to flattenedGlobalWordVector.Length-1 do
        if (doc.wordvector.ContainsKey(flattenedGlobalWordVector.[i].Key)) then
            let (wf, tfidf) = doc.wordvector.[flattenedGlobalWordVector.[i].Key]
            list.Add(new Node(i+1, range.Transform(tfidf, i+1)))
    list.ToArray()  
    



// we assume both the 'technology' bit and the flattened word vector are available
let trainSupportVectorMachine (docoments: Document list) = 
    let flattenedGlobalWordVector = dictionaryToArray globalTermFrequency
    let nodeArray = docoments |> List.map (fun document ->  let list = new List<Node>()
                                                            for i = 0 to flattenedGlobalWordVector.Length-1 do
                                                                if (document.wordvector.ContainsKey(flattenedGlobalWordVector.[i].Key)) then
                                                                    let (wf, tfidf) = document.wordvector.[flattenedGlobalWordVector.[i].Key]
                                                                    list.Add(new Node(i+1, tfidf))
                                                            list.ToArray()) |> Seq.to_array
    let technologyArray = docoments |> List.map (fun document -> if document.classified then 1.0 else 0.0) |> Seq.to_array
    let problem = new Problem(technologyArray.Length, technologyArray, nodeArray, flattenedGlobalWordVector.Length)
    let range = Scaling.DetermineRange(problem)
    let scaledProblem = Scaling.Scale(problem, range)    
    let parameters = new Parameter()
    parameters.C <- 1.0
    parameters.Gamma <- 0.2
    (Training.Train(scaledProblem, parameters), range)
    
    
  

// Initializes SVM.NET and trains it with 
// a selection of 'technology' related documents.
let initializeSupportVectorMachine () =
    let globalVector = Seq.to_list globalTermFrequency
    documents |> List.iter (fun document -> document.flatvector <- globalVector |> List.map (fun x -> if (document.wordvector.ContainsKey(x.Key)) then 
                                                                                                            let (wf, tfidf) = document.wordvector.[x.Key]
                                                                                                            tfidf
                                                                                                         else
                                                                                                            0.0))
                                                                                                            
    // check to see if it has technology stuff in it, and update the 'classifier' flag appropriately
    documents |> List.iter (fun document -> let techWords = Seq.to_list document.wordvector |> List.sumBy (fun x -> if svmWords.ContainsKey(x.Key) then 
                                                                                                                        let (tf, idf) = x.Value
                                                                                                                        tf
                                                                                                                    else 0)
                                            if techWords > 4 then
                                                document.classified  <- true
                                            else
                                                document.classified <- false)


    // now train the support vector machine accordingly
    let passDocuments = documents |> List.filter (fun x -> x.classified) 
    let failDocuments = documents |> List.filter (fun x -> not (x.classified)) |> take 1000
    let total = List.append passDocuments failDocuments

    let (a, b) = trainSupportVectorMachine total
    model <- a
    range <- b
    
    

