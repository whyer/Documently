﻿#light

open System
open System.IO
open System.Collections.Generic
open System.Diagnostics
open System.ServiceModel
open Program
open Helpers
open Types
open Distance
open SVMClassifier
open SVM


[<ServiceContract(Name = "SearchService", Namespace = "http://callvirt.net/samples", ConfigurationName = "ISearchService")>]
type ISearchService =
    [< OperationContract >]
    abstract Search: searchTerms: string -> SearchResult


[<ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)>] 
type SearchService() =
    interface ISearchService with
        member s.Search(searchTerms: string) : SearchResult =
            let searchResults = search (Array.to_list (searchTerms.Split([|' '|])))
            if (searchResults.Length < 4) then
                new SearchResult(DidYouMean = getDidYouMean (Array.to_list (searchTerms.Split([|' '|]))), Results = listToGenericList (searchResults |> List.map (fun (x, res) -> new SearchResultItem(Location = x.location, Title = x.title, RssUrl = x.rssurl, Author = x.author, Date = x.date, Certainty = res, Category = false))))
            else
                  new SearchResult(DidYouMean = "", Results = listToGenericList (searchResults |> List.map (fun (x, res) -> new SearchResultItem(Location = x.location, Title = x.title, RssUrl = x.rssurl, Author = x.author, Date = x.date, Certainty = res, Category = false))))
             



//        member s.Search(searchTerms: string) : SearchResult =
//            let searchResults = search (Array.to_list (searchTerms.Split([|' '|])))
//            let predResults = searchResults |> List.map (fun (x, freq) -> let classification = Prediction.Predict(model, (documentToSVMModel x range))
//                                                                          new SearchResultItem(Location = x.location, Title = x.title, RssUrl = x.rssurl, Author = x.author, Date = x.date, Certainty = freq, Category = (floatToBool classification)))
//            new SearchResult(DidYouMean = "", Results = listToGenericList (predResults))




let main() =
    Console.WriteLine("Blog Search Engine = " + typeof<SearchService>.ToString())
    
    // fire up the search engine
    Console.WriteLine("crawling blogs on disk...");
    initializeSearchEngine () |> ignore
    
    //Console.WriteLine("instantiating support vector machine with data from svmwords.txt")
    //initializeSupportVectorMachine () |> ignore
    
    Console.WriteLine("starting service...")
    let hisType = typeof<SearchService>
    let host = new ServiceHost(hisType, ([| |] : Uri[] ) )
    host.Open()
    Console.WriteLine("Press <ENTER> to terminate the host application")
    Console.ReadLine() |> ignore
    host.Close()


main()