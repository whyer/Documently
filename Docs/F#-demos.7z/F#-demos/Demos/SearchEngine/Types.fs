﻿#light

open System
open System.IO
open System.Collections.Generic
open System.Diagnostics
open System.Text
open System.Threading
open System.ServiceModel
open System.Runtime.Serialization
open SVM


// Type that represents a blog post
type Document = {
    location: string;
    title: string;
    rssurl: string;
    author: string    
    date: DateTime;
    links: string list;
    // contains the term and (termCount * tfidf) tuple
    wordvector: Dictionary<string, (int * double)>;
    
    // used for SVM classification
    mutable flatvector: double list;
    mutable classified: bool;
}


// State for the search engine
let globalTermFrequency = new Dictionary<string, int>()
let mutable documents: Document list = []

// State for the SVM classifier
let mutable model: Model = null
let mutable range: RangeTransform = null







// WCF contracts 
[<DataContract(Namespace="http://callvirt.net/samples")>]
type SearchResultItem () = 
    let mutable location: string = String.Empty
    let mutable title: string = String.Empty
    let mutable rssurl: string = String.Empty
    let mutable author: string = String.Empty
    let mutable date: DateTime = DateTime.MinValue
    let mutable certainty: double = 0.0
    let mutable category: bool = false

    [<DataMember(Name = "Location", IsRequired = false, Order = 0)>]
    member public l.Location
        with get() = location
        and set(value) = location <- value
    
    [<DataMember(Name = "Title", IsRequired = false, Order = 1)>]
    member public l.Title
        with get() = title
        and set(value) = title <- value
    
    [<DataMember(Name = "RssUrl", IsRequired = false, Order = 2)>]
    member public l.RssUrl
        with get() = rssurl
        and set(value) = rssurl <- value
    
    [<DataMember(Name = "Author", IsRequired = false, Order = 3)>]
    member public l.Author
        with get() = author
        and set(value) = author <- value
        
    [<DataMember(Name = "Date", IsRequired = false, Order = 4)>]
    member public l.Date
        with get() = date
        and set(value) = date <- value
        
    [<DataMember(Name = "Certainty", IsRequired = false, Order = 5)>]
    member public l.Certainty
        with get() = certainty
        and set(value) = certainty <- value
    
    [<DataMember(Name = "Category", IsRequired = false, Order = 6)>]
    member public l.Category
        with get() = category
        and set(value) = category <- value
    

[<DataContract(Namespace="http://callvirt.net/samples", Name="SearchResultContract")>]
type SearchResult () = 
    let mutable didYouMean: string = String.Empty
    let mutable results: List<SearchResultItem> = new List<SearchResultItem>()

    [<DataMember(Name = "DidYouMean", IsRequired = false, Order = 0)>]
    member public l.DidYouMean
        with get() = didYouMean
        and set(value) = didYouMean <- value
        
    [<DataMember(Name = "Results", IsRequired = false, Order = 1)>]
    member public l.Results
        with get() = results
        and set(value) = results <- value
        