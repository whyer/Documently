﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.IO;
using System.Web.UI.WebControls;
using callvirt.net.samples;

namespace SearchEngine
{
    public partial class Results : System.Web.UI.Page
    {
        internal static string StripHtml(string document)
        {
            // make sure it removes all the non-ascii characters
            string res = Encoding.ASCII.GetString(
            Encoding.Convert(
                Encoding.UTF8,
                Encoding.GetEncoding(
                    Encoding.ASCII.EncodingName,
                    new EncoderReplacementFallback(string.Empty),
                    new DecoderExceptionFallback()
                    ),
                Encoding.UTF8.GetBytes(document)
            ));

            // strip the HTML
            string regexPattern = "(<[^>]*/>)|(<[^>]*>)([^>]*>)?";
            res = Regex.Replace(res, regexPattern, string.Empty, RegexOptions.Compiled);

            // strip the carriage return line feeds
            res = res.Replace("\r", " ").Replace("\n", " ");

            return res;
        }

        protected string ResultsList = "";
        protected string DidYouMean = "";
        protected string LastQuery = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            string query = "";
            if (!string.IsNullOrEmpty(Request.Form["q"]))
                query = Request.Form["q"];
            if (!string.IsNullOrEmpty(Request.QueryString["q"]))
                query = Request.QueryString["q"];

            if (!string.IsNullOrEmpty(query))
            {
                SearchServiceClient client = new SearchServiceClient();
                SearchResultContract result = client.Search(query.ToLower());

                if (!string.IsNullOrEmpty(result.DidYouMean))
                    DidYouMean = string.Format("Did you mean <a href=\"Results.aspx?q={0}\">{0}</a>?", result.DidYouMean);

                foreach (var q in result.Results)
                {
                    ResultsList += EmitHTMLForBlogItem(q);
                }

                LastQuery = query;
            }
        }

        protected string EmitHTMLForBlogItem(TypesSearchResultItem item)
        {
            // suck up part of the actual document
            string document = "";
            using (StreamReader reader = new StreamReader(item.Location))
                document = reader.ReadToEnd();

            document = document.Substring(document.IndexOf("[[]]")+4);

            string stripped = StripHtml(document);

            if (stripped.Length > 400)
                stripped = stripped.Substring(0, 400);

            if (item.Category)
            {
                return string.Format("<div id=\"myresults\" style=\"background-color: #CCFFFF;\"><h3><a href=\"{0}\">{1}</a></h3><span>{2}</span><p>{3}</p><a href=\"{4}\">..</a><span style=\"color: Green\">{5} <a href=\"{6}\">{7}</a></span>",
                        item.RssUrl, item.Title, item.Certainty, stripped, item.Location, item.Date, item.RssUrl, item.Author);
            }
            else
            {
                return string.Format("<div id=\"myresults\"><h3><a href=\"{0}\">{1}</a></h3><span>{2}</span><p>{3}</p><a href=\"{4}\">..</a><span style=\"color: Green\">{5} <a href=\"{6}\">{7}</a></span>",
                         item.RssUrl, item.Title, item.Certainty, stripped, item.Location, item.Date, item.RssUrl, item.Author);
            }
        }
    }
}
